package com.fishymathematics.equationgenerator;


public class EquationGenerator {

    public enum EquationType {
        ONE_STEP,
        TWO_STEP,
        TWO_STEP_DISTRIBUTING,
        COMBINING_LIKE_TERMS,
        VARIABLES_BOTH_SIDES,
        VARIABLES_BOTH_SIDES_COMBINING,
        VARIABLES_BOTH_SIDES_DISTRIBUTIVE,
        DIFFICULT_MULTI_STEP_EQUATION
    }

    private boolean rational;
    private EquationType type;
    double x, a, b, c, d, e, f, g, h;
    private final double rounding = 10000.0;
    private String[] equationAnswer = new String[2];

    public EquationGenerator (boolean rational, EquationType type) {
        this.rational = rational;
        this.type = type;
    }

    public String getEquation() {
        return "\\(" + removeTrailingZero(removeDoubleSigns(equationAnswer[0])) + "\\)";
    }

    public String getAnswer() {
        return "\\(" + removeTrailingZero(equationAnswer[1]) + "\\)";
    }

    public void generate() {
        switch (type) {
            case ONE_STEP:
                oneStepEquation();
                break;
            case TWO_STEP:
                twoStepEquation();
                break;
            case TWO_STEP_DISTRIBUTING:
                twoStepDistributing();
                break;
            case COMBINING_LIKE_TERMS:
                combiningLikeTerms();
                break;
            case VARIABLES_BOTH_SIDES:
                variablesOnBothSides();
                break;
            case VARIABLES_BOTH_SIDES_COMBINING:
                variablesOnBothSidesWithCombining();
                break;
            case VARIABLES_BOTH_SIDES_DISTRIBUTIVE:
                variablesOnBothSidesWithDistributing();
                break;
            case DIFFICULT_MULTI_STEP_EQUATION:
                difficultMultStep();
                break;
            default:
                // Nothing
        }
    }

    private void oneStepEquation() {
        switch ((int)this.random(0, 3)) {
            case 0:
                // TODO remove magic numbers?
                x = nonZeroRandom(-10, 10);
                a = nonZeroRandom(-10, 10);
                b = Math.round((x * a) * rounding) / rounding;
                equationAnswer[0] = a + "x = " + b;
                equationAnswer[1] = x + "";
                break;
            case 1:
                x = nonZeroRandom(-10, 10);
                a = nonZeroRandom(-10, 10);
                b = Math.round((x + a) * rounding) / rounding;
                equationAnswer[0] = a + " + x = " + b;
                equationAnswer[1] = x + "";
                break;
            case 2:
                x = nonZeroRandom(-10, 10);
                a = nonZeroRandom(-10, 10);
                b = Math.round((x - a) * rounding) / rounding;
                equationAnswer[0] = "x - " + a + " = " + b;
                equationAnswer[1] = x + "";
                break;
            case 3:
                a = nonZeroRandom(-10, 10);
                b = nonZeroRandom(-10, 10);
                x = Math.round((b * a) * rounding) / rounding;
                // TODO fix equation and use math symbols
                equationAnswer[0] = "\\frac{x}{" + a + "} = " + b;
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void twoStepEquation() {
        switch ((int) random(0,3)) {
            case 0:
                a = nonZeroRandom(-10, 10);
                do{ b = random(2, 10); } while (b == a);
                x = nonZeroRandom(-10, 10);
                c = Math.round((a * x + b) * rounding) / rounding;
                equationAnswer[0] = a + "x + " + b + " = " + c;
                equationAnswer[1] = x + "";
                break;
            case 1:
                a = nonZeroRandom(-10, 10);
                do { b = random(2, 10); } while (b == a);
                x = nonZeroRandom(-10, 10);
                c = Math.round((a * x + b) * rounding) / rounding;
                equationAnswer[0] = c + " = " + b + " + " + a + "x";
                equationAnswer[1] = x + "";
                break;
            case 2:
                a = nonZeroRandom(-10, 10);
                do { b = random(2, 10); } while (b == a);
                x = nonZeroRandom(-10, 10);
                c = Math.round((a * x + b) * rounding) / rounding;
                equationAnswer[0] = c + " = " + b + " + " + a + "x";
                equationAnswer[1] = x + "";
                break;
            case 3:
                a = random(2, 10);
                b = nonZeroRandom(-10,10);
                do { c = nonZeroRandom(-10,10); } while (b == c);
                x = Math.round(((c - b) * a) * rounding) / rounding;
                // TODO fix math fraction
                equationAnswer[0] = "\\frac{x}{" + a + "} + " + b + " = " + c;
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void twoStepDistributing() {
        switch((int) random(0,2)) {
            case 0:
                a = nonZeroRandom(-10, 10);
                do { b = random(2, 15); } while (b == a);
                do { c = random(2, 15); } while (c == b || c == a);
                x = random(2, 15);
                d = Math.round((a * (c * x + b)) * rounding) / rounding;
                equationAnswer[0] = a + "(" + c + "x + " + b + ") = " + d;
                equationAnswer[1] = x + "";
                break;
            case 1:
                a = nonZeroRandom(-10, 10);
                do { b = random(2, 15); } while (b ==  a);
                do { c = random(2, 15); } while (c == b || c == a);
                x = random(2, 15);
                d = Math.round((a * (c * x + b)) * rounding) / rounding;
                equationAnswer[0] = d + " = " + a + "(" + c + "x + " + b + ")";
                equationAnswer[1] = x + "";
                break;
            case 2:
                a = nonZeroRandom(-10, 10);
                do { b = random(2, 15); } while (b ==  a);
                do { c = random(2, 15); } while (c == b || c == a);
                x = random(2, 15);
                d = Math.round((a * (c * x + b)) * rounding) / rounding;
                equationAnswer[0] = d + " = " + a + "(" + b + "x + " + c + ")";
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void combiningLikeTerms() {
        switch((int) random(0,3)) {
            case 0:
                a = random(2, 15);
                x = nonZeroRandom(-12, 12);
                do { b = random(2, 10); } while (b == a);
                do { c = random(2, 10); } while (c == b || c == a);
                d = Math.round((a * x + b - c * x) * rounding) / rounding;
                equationAnswer[0] = a + "x + " + b + " - " + c + "x = " + d;
                equationAnswer[1] = x + "";
                break;
            case 1:
                a = random(-15, -5);
                x = nonZeroRandom(-20, -5);
                do { b = random(5, 35); } while (b == a);
                d = random(2, 15);
                c = Math.round((a * x - a * b + d) * rounding) / rounding;
                equationAnswer[0] = a + "(x - " + b + ") + " + d + " = " + c;
                equationAnswer[1] = x + "";
                break;
            case 2:
                a = random(2, 15);
                x = nonZeroRandom(-12, 12);
                do { b = random(2, 10); } while (b == a);
                do { c = random(2, 10); } while (c == b || c == a);
                d = Math.round((a * x + b - c * x) * rounding) / rounding;
                equationAnswer[0] = d + " = " + a + "x + " + b + " - " + c + "x";
                equationAnswer[1] = x + "";
                break;
            case 3:
                a = random(-15, 5);
                x = nonZeroRandom(-20, -5);
                do { b = random(5, 35); } while (b == a);
                d = random(2, 15);
                c = Math.round((a * x - a * b + d) * rounding) / rounding;
                equationAnswer[0] = c + " = " + a + "(x - " + b + ") + " + d;
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void variablesOnBothSides() {
        switch((int) random(0,1)) {
            case 0:
                do {
                    c = random(2, 5);
                    b = random(2, 10);
                    x = nonZeroRandom(-10, 10);
                    a = random(2, 5) + c;
                    d = Math.round((a * x + b - c * x) * rounding) / rounding;
                } while (d == 0);
                equationAnswer[0] = a + "x + " + b + " = " + c + "x + " + d;
                equationAnswer[1] = x + "";
                break;
            case 1:
                do {
                    c = random(2, 5);
                    b = random(2, 10);
                    x = nonZeroRandom(-10, 10);
                    a = random(2, 5) + c;
                    d = Math.round((a * x + b - c * x) * rounding) / rounding;
                } while (d == 0);
                equationAnswer[0] = d + " + " + c + "x = " + a + "x + " + b;
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void variablesOnBothSidesWithCombining() {
        switch((int) random(0,2)) {
            case 0:
                x = nonZeroRandom(-10,10);
                a = nonZeroRandom(-10,10);
                b = nonZeroRandom(-10,10);
                c = nonZeroRandom(-10,10);
                d = nonZeroRandom(-10,10);
                e = nonZeroRandom(-10,10);
                f = Math.round((a + b * x - (c * x + d + e * x)) * rounding) / rounding;
                equationAnswer[0] = a + " + " + b + "x = " + c + "x + " + d + " + " + e + "x + " + f;
                equationAnswer[1] = x + "";
                break;
            case 1:
                x = nonZeroRandom(-10,10);
                a = nonZeroRandom(-10,10);
                b = nonZeroRandom(-10,10);
                c = nonZeroRandom(-10,10);
                d = nonZeroRandom(-10,10);
                e = nonZeroRandom(-10,10);
                f = Math.round((a + b * x + d - (c * x + e * x)) * rounding) / rounding;
                equationAnswer[0] = a + " + " + b + "x +" + d + "= " + c + "x + " + f + " + " + e + "x";
                equationAnswer[1] = x + "";
                break;
            case 2:
                x = nonZeroRandom(-10,10);
                a = nonZeroRandom(-10,10);
                b = nonZeroRandom(-10,10);
                c = nonZeroRandom(-10,10);
                d = nonZeroRandom(-10,10);
                e = nonZeroRandom(-10,10);
                f = Math.round((a * x + b * x + d - (c * x + e * x)) * rounding) / rounding;
                equationAnswer[0] = b + "x +" + d + " + " + a + "x = " + c + "x + " + f + " + " + e + "x";
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void variablesOnBothSidesWithDistributing() {
        switch((int) random(0, 3)) {
            case 0:
                a = random(2, 5);
                b = random(2, 10);
                x = nonZeroRandom(-10, 10);
                c = Math.round((a * (x + b) - x) * rounding) / rounding;
                equationAnswer[0] = a + "(x + " + b + ") = x + " + c;
                equationAnswer[1] = x + "";
                break;
            case 1:
                a = random(2, 5);
                b = random(2, 10);
                x = nonZeroRandom(-10, 10);
                c = Math.round((a * (x + b) - x) * rounding) / rounding;
                equationAnswer[0] = "x + " + c + " = " + a + "(x + " + b + ")";
                equationAnswer[1] = x + "";
                break;
            case 2:
                a = random(2, 5);
                b = random(2, 10);
                x = nonZeroRandom(-10, 10);
                c = Math.round((a * (d * x + b) - x) * rounding) / rounding;
                equationAnswer[0] = "x + " + c + " = " + a + "(" + d + "x + " + b + ")";
                equationAnswer[1] = x + "";
                break;
            case 3:
                a = random(2, 5);
                b = random(2, 10);
                x = nonZeroRandom(-10, 10);
                d = nonZeroRandom(-10, 10);
                e = nonZeroRandom(-10, 10);
                c = Math.round((a * (d * x + b) - (e * x)) * rounding) / rounding;
                equationAnswer[0] = e + "x + " + c + " = " + a + "(" + d + "x + " + b + ")";
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private void difficultMultStep() {
        switch((int) random(0, 1)) {
            case 0:
                x = nonZeroRandom(-10,10);
                b = nonZeroRandom(-10,10);
                c = nonZeroRandom(-10,10);
                d = nonZeroRandom(-10,10);
                e = nonZeroRandom(-10,10);
                f = nonZeroRandom(-10,10);
                g = nonZeroRandom(-10,10);
                h = nonZeroRandom(-10,10);
                a = Math.round(((e + f * (g * x + h)) - (b * (c * x + d))) * rounding)/rounding;
                equationAnswer[0] = a + " + " + b + "(" + c + "x + " + d + ") = " + e + " + " + f + "(" + g + "x + " + h + ")";
                equationAnswer[1] = x + "";
                break;
            case 1:
                x = nonZeroRandom(-10,10);
                b = nonZeroRandom(-10,10);
                c = nonZeroRandom(-10,10);
                d = nonZeroRandom(-10,10);
                e = nonZeroRandom(-10,10);
                f = nonZeroRandom(-10,10);
                g = nonZeroRandom(-10,10);
                h = nonZeroRandom(-10,10);
                a = Math.round((a * (b * x + c) + d * (e * x + f) - g * x) * rounding)/rounding;
                equationAnswer[0] = a + "(" + b + "x + " + c + ") + " + d + "(" + e + "x + " + f + ") = " + g + "x +" + h;
                equationAnswer[1] = x + "";
                break;
            default:
                // Nothing
        }
    }

    private String removeDoubleSigns(String equation) {
        equation = equation.replace("-+", "-");
        equation = equation.replace("+-", "-");
        equation = equation.replace("- +", "-");
        equation = equation.replace("+ -", "-");
        equation = equation.replace("- -", "+");
        equation = equation.replace("--", "+");

        return equation;
    }

    private String removeTrailingZero(String equation) {
        equation = equation.replaceAll("([0-9]+\\.[0-9]*)(0+)($| |x|\\)|\\}){1}", "$1$3");
        equation = equation.replaceAll("([0-9]+)(\\.)([^0-9]|$)","$1$3");

        return equation;
    }

    private double nonZeroRandom(int min, int max) {
        double random = random(min, max);

        while (random == 0) {
            random = random(min, max);
        }

        return random;
    }

    private double random(int min, int max) {
        double random;

        if (rational) {
            // TODO make decimal places a field and not a magic number
            random = randomDecimal(min, max, 1);
        } else {
            random = Math.floor(Math.random() * (max - min + 1)) + min;
        }

        return random;
    }

    private double randomDecimal(int min, int max, int decimalPlaces) {
        double random = Math.random() * (max - min) + min;
        // TODO make 10 a field and not a magic number
        double power = Math.pow(10, decimalPlaces);

        return Math.floor(random * power) / power;
    }
}
