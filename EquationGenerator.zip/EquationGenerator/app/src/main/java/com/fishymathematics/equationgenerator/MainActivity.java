package com.fishymathematics.equationgenerator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import io.github.kexanie.library.MathView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Spinner equationType = findViewById(R.id.equationType);
        final Switch rationals = findViewById(R.id.rationals);
        final Switch showAnswer = findViewById(R.id.showAnswer);
        final MathView equationView = findViewById(R.id.equationView);
        final MathView answerView = findViewById(R.id.answerView);
        final Button generateEquation = findViewById(R.id.generateEquation);

        equationView.setOnKeyListener(null);
        answerView.setOnKeyListener(null);

        equationView.config(
                "MathJax.Hub.Config({\n"+
                        "  CommonHTML: { linebreaks: { automatic: true } },\n"+
                        "  \"HTML-CSS\": { linebreaks: { automatic: true } },\n"+
                        "         SVG: { linebreaks: { automatic: true } }\n"+
                        "});");

        answerView.config(
                "MathJax.Hub.Config({\n"+
                        "  CommonHTML: { linebreaks: { automatic: true } },\n"+
                        "  \"HTML-CSS\": { linebreaks: { automatic: true } },\n"+
                        "         SVG: { linebreaks: { automatic: true } }\n"+
                        "});");


        boolean checked = showAnswer.isChecked();

        if(checked) {
            answerView.setVisibility(TextView.VISIBLE);
        } else {
            answerView.setVisibility(TextView.INVISIBLE);
        }

        generateEquation.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int selectedType = equationType.getSelectedItemPosition();
                EquationGenerator.EquationType type = null;

                switch(selectedType) {
                    case 0:
                        type = EquationGenerator.EquationType.ONE_STEP;
                        break;
                    case 1:
                        type = EquationGenerator.EquationType.TWO_STEP;
                        break;
                    case 2:
                        type = EquationGenerator.EquationType.TWO_STEP_DISTRIBUTING;
                        break;
                    case 3:
                        type = EquationGenerator.EquationType.COMBINING_LIKE_TERMS;
                        break;
                    case 4:
                        type = EquationGenerator.EquationType.VARIABLES_BOTH_SIDES;
                        break;
                    case 5:
                        type = EquationGenerator.EquationType.VARIABLES_BOTH_SIDES_COMBINING;
                        break;
                    case 6:
                        type = EquationGenerator.EquationType.VARIABLES_BOTH_SIDES_DISTRIBUTIVE;
                        break;
                    case 7:
                        type = EquationGenerator.EquationType.DIFFICULT_MULTI_STEP_EQUATION;
                        break;
                    default:
                        // Nothing
                }

                boolean rational = rationals.isChecked();

                if (type != null) {
                    EquationGenerator newEquation = new EquationGenerator(rational, type);
                    newEquation.generate();
                    String equation = newEquation.getEquation();
                    String answer = newEquation.getAnswer();

                    equationView.setText(equation);
                    answerView.setText(answer);
                }
            }
        });

        showAnswer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    answerView.setVisibility(TextView.VISIBLE);
                } else {
                    answerView.setVisibility(TextView.INVISIBLE);
                }
            }
        });
    }
}
